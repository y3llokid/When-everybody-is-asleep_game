﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpinningAxe : MonoBehaviour
{
    public float damage = 2f;
    public float acceleration = 0.05f;
    public float speed = 1f;
    public Rigidbody2D rigidBody;
    public GameObject hittingEffect;

    void Start()
    {
        rigidBody.velocity = transform.right * speed;
        FindObjectOfType<AudioManager>().Play("SpinningAxe");

    }

    private void Update()
    {

        rigidBody.velocity = rigidBody.velocity * acceleration;

    }
    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
        if(hitInfo.tag == "Player" || hitInfo.tag == "PlayerAttack")
        {
            if(thePlayer != null && thePlayer.tag == "Player")
            {
                thePlayer.TakeDamage(damage);
            }
            Destroy(gameObject);
        }
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
}

 
