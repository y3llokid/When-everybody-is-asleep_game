﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class Youwin : MonoBehaviour
{
    public TextMeshProUGUI yourRecord;


    IEnumerator Start()
    {
        FindObjectOfType<AudioManager>().StopAll();
        FindObjectOfType<AudioManager>().Play("Youwin");
        yourRecord.text = PlayerPrefs.GetString("ThisScore", "-----");
        if(PlayerPrefs.GetFloat("ThisScore_float", 3000) < 180)
        {
            yield return new WaitForSeconds(12);
            SceneManager.LoadScene("EasterEgg");
        }
    }

    public void Play()
    {
        FindObjectOfType<AudioManager>().Stop("Youwin");
        FindObjectOfType<AudioManager>().Play("BGM_1stPhase");
        FindObjectOfType<AudioManager>().Play("ClickSound");
        SceneManager.LoadScene("BossFight");
    }

    public void Menu()
    {
        SceneManager.LoadScene("Mainmenu");
    }

    public void Exit()
    {
        Application.Quit();
    }
}
