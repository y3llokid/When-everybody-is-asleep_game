﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletSniper : MonoBehaviour
{
    private float damage;
    public float minDamage = 25;
    public float maxDamage = 36;
    public float speed = 20f;
    public Rigidbody2D rigidBody;
    public GameObject hittingEffect;
    // Start is called before the first frame update
    void Start()
    {
        rigidBody.velocity = transform.right * speed;
        damage = Random.Range(minDamage, maxDamage);
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        TheMonster theMonster = hitInfo.GetComponent<TheMonster>();
        if (theMonster != null)
        {
            if (theMonster.health < 1000)
            {
                if (!theMonster.animator.GetCurrentAnimatorStateInfo(0).IsName("2ndPhase_IDLE"))
                {
                    Instantiate(hittingEffect, transform.position, Quaternion.identity);
                    Destroy(gameObject);
                }
                else
                {
                    theMonster.TakeDamage(damage);
                }
            }
            else
            {
                theMonster.TakeDamage(damage);
            }
        }
        Instantiate(hittingEffect, transform.position, Quaternion.identity);
        Destroy(gameObject);
    }
}
