﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EyeBullet : MonoBehaviour
{
    public float damage = 10f;
    public float speed = 20f;
    public Rigidbody2D rigidBody;
    public GameObject hittingEffect;

    void Start()
    {
        rigidBody.velocity = transform.right * speed;
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
        if (thePlayer != null && thePlayer.tag == "Player")
        {
            thePlayer.TakeDamage(damage);
            Destroy(gameObject);
        }
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
}
