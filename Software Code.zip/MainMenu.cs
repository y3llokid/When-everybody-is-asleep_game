﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class MainMenu : MonoBehaviour
{
    public TextMeshProUGUI highScore;
    public TextMeshProUGUI lastScore;

    private void Start()
    {
        FindObjectOfType<AudioManager>().StopAll();
        FindObjectOfType<AudioManager>().Play("BGM_1stPhase");
        highScore.text = PlayerPrefs.GetString("HighScore", "-----");
        lastScore.text = PlayerPrefs.GetString("ThisScore", "-----");
    }

    public void PlayGame()
    {
        FindObjectOfType<AudioManager>().Play("ClickSound");
        SceneManager.LoadScene("BossFight");
    }

    public void Exit()
    {
        Application.Quit();
    }

    public void Reset()
    {
        PlayerPrefs.DeleteKey("HighScore");
        PlayerPrefs.DeleteKey("HighScore_float");
    }
}
