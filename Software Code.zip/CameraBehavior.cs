﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraBehavior : MonoBehaviour
{
    public Transform player;
    public float smoothSpeed = 0.125f;
    private float xMax = 6.5f;
    private float xMin = -6.5f;
    private float yMax = 2.7f;
    private float yMin = -5f;

    private float shakeDuration = 0f;
    private float shakeMagnitude = 0.7f;
    private float dampingSpeed = 1.0f;
    private bool isShakeTriggered = false;
    private Vector3 initialPosition;

    private Vector3 offset;
    // Start is called before the first frame update
    void Start()
    {
        offset = transform.position - player.position;
    }

    private void OnEnable()
    {
        initialPosition = transform.localPosition;
    }
    private void Update()
    {
        if (isShakeTriggered)
        {
            if (shakeDuration > 0)
            {
                transform.localPosition = initialPosition + Random.insideUnitSphere * shakeMagnitude;

                shakeDuration -= Time.deltaTime * dampingSpeed;
            }
            else
            {
                shakeDuration = 0f;
                transform.localPosition = initialPosition;
                isShakeTriggered = false;
            }
        }
    }
    // Update is called once per frame
    private void LateUpdate()
    {

        Vector3 desiredPosition = player.position + offset;
        if(desiredPosition.x < -3.3)
        {
            desiredPosition = new Vector3(xMin, desiredPosition.y, -10);
        }
        if(desiredPosition.x > 3.3)
        {
            desiredPosition = new Vector3(xMax, desiredPosition.y, -10);

        }
        if (desiredPosition.y < -5)
        {
            desiredPosition = new Vector3(desiredPosition.x, yMin, -10);

        }
        if (desiredPosition.y > 2.7)
        {
            desiredPosition = new Vector3(desiredPosition.x, yMax, -10);

        }
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        transform.position = smoothedPosition;
    }

    public void TriggerShake()
    {
        isShakeTriggered = true;
        shakeDuration = 2.0f;
    }
}
