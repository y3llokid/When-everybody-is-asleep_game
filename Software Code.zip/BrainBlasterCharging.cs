﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrainBlasterCharging : MonoBehaviour
{
    public GameObject brainBlaster;

    void Start()
    {
        Invoke("BrainBlaster", 0.8f);
    }

    void BrainBlaster()
    {
        Destroy(gameObject);
        Instantiate(brainBlaster, transform.position, transform.rotation);
    }
}
