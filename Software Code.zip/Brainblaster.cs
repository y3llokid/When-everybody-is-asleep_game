﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brainblaster : MonoBehaviour
{
    public float damage = 10f;
    public GameObject fadeout;

    private void Start()
    {
        Invoke("FinishTheSkill", 1f);
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
        if (thePlayer != null)
        {
            thePlayer.TakeDamage(damage);
        }
    }

    public void FinishTheSkill()
    {
        Destroy(gameObject);
        Instantiate(fadeout, transform.position, transform.rotation);
    }
}
