﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BloodShower : MonoBehaviour
{
    public float damage = 20f;
    public GameObject hittingEffect;
    public Rigidbody2D rigid;

    private void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
        rigid.gravityScale = 0;
        Invoke("StartFalling", 0.75f);
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
        if (thePlayer != null && thePlayer.tag == "Player")
        {
            thePlayer.TakeDamage(damage);
        }
        Destroy(gameObject);
        Instantiate(hittingEffect, transform.position, Quaternion.identity);
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    public void StartFalling()
    {
        rigid.gravityScale = 1.5f;
    }
}
