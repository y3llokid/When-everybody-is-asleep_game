﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkullBomb : MonoBehaviour
{
    public float damage = 7f;
    public float speed = 7f;
    public Rigidbody2D rigidBody;
    public CircleCollider2D circleCollider2D;
    public GameObject hittingEffect;
    public GameObject Explosion;
    public int bounceCount;

    void Start()
    {
        rigidBody.velocity = transform.right * speed;
        circleCollider2D = GetComponent<CircleCollider2D>();
        bounceCount = 0;
    }

    private void Update()
    {
        if (bounceCount > 2)
        {
            circleCollider2D.isTrigger = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
        if (hitInfo.tag != "Monster" && hitInfo.tag != "PlayerAttack" && hitInfo.tag != "MonsterAttack" && hitInfo.tag != "Monster")
        {
            if (thePlayer != null && thePlayer.tag == "Player")
            {
                thePlayer.TakeDamage(damage);
                
            }
			Instantiate(hittingEffect, transform.position, Quaternion.identity);
            Instantiate(Explosion, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        FindObjectOfType<AudioManager>().Play("SkullBomb");

        ThePlayer thePlayer = collision.collider.GetComponent<ThePlayer>();
        if(thePlayer != null && collision.collider.tag == "Player")
        {
            thePlayer.TakeDamage(damage);
            Instantiate(hittingEffect, transform.position, Quaternion.identity);
            Instantiate(Explosion, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
        bounceCount += 1;
    }
}
