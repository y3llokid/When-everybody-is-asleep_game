﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealingZone : MonoBehaviour
{
    public float healingAmount = 1.5f;
    private bool isBeingPet;
    private Animator animator;

    void Start()
    {
        isBeingPet = false;
        animator = GetComponent<Animator>();
        animator.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (isBeingPet)
        {
            GameObject thePlayer = GameObject.Find("ThePlayer");
            ThePlayer thePlayerScript = thePlayer.GetComponent<ThePlayer>();
            if (thePlayerScript.health < 100)
            {
                thePlayerScript.health = thePlayerScript.health + healingAmount * Time.deltaTime;
                thePlayerScript.healthbar.value = thePlayerScript.health;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            isBeingPet = true;
            animator.enabled = true;
        }
    }


    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            isBeingPet = false;
            animator.enabled = false;
        }       
    }
}
