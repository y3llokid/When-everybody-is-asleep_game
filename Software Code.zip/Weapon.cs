﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    public Transform firePoint;
    public Transform firePoint_Sniper;
    public GameObject bulletPrefab;
    public GameObject bullet_Sniper;
    public GameObject shootingEffect;
    public GameObject shootingEffect_Sniper;
    Animator animator;

    // Update is called once per frame
    private void Awake()
    {
        animator = GetComponent<Animator>();
    }
    void Update()
    {
        if (FindObjectOfType<ThePlayer>().health > 0)
        {
            if (Input.GetButtonDown("Fire1"))
            {
                Shoot();
                if (animator.GetBool("isSniper"))
                {
                    FindObjectOfType<AudioManager>().Play("ShootPlayerSniperBullet");

                }
                else
                {
                    FindObjectOfType<AudioManager>().Play("ShootPlayerBullet");
                }
            }
        }
    }

    void Shoot()
    {
        if (animator.GetBool("isSniper") == true)
        {
            Instantiate(bullet_Sniper, firePoint_Sniper.position, firePoint_Sniper.rotation);
            Instantiate(shootingEffect_Sniper, firePoint_Sniper.position, firePoint_Sniper.rotation);
        }
        else
        {
            if (animator.GetComponent("isWalking") == false)
                animator.SetBool("isIdleShooting", true);
            Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
            Instantiate(shootingEffect, firePoint.position, firePoint.rotation);
        }
    }
}
