﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skills : MonoBehaviour
{
    public Transform firepointEye;
    public Transform firepointMouth;
    public Transform firepointAxe0;
    public Transform firepointAxe1;
    public Transform firepointAxe2;
    public Transform firepointAxe3;
    public Transform firepointAxe4;
    public Transform firepointAxe5;
    public Transform firepointBloodShower0;
    public Transform firepointBloodShower1;
    public Transform firepointBloodShower2;
    public Transform firepointBloodShower3;
    public Transform firepointBloodShower4;
    public Transform firepointBloodShower5;
    public Transform firepointBloodShower6;
    public Transform firepointEyeBlaster;
    public Transform firepointHellfire;
    public Transform firepointBrainblaster0;
    public Transform firepointBrainblaster1;
    public Transform firepointBrainblaster2;
    public Transform firepointBrainblaster3;
    public Transform firepointBrainblaster4;
    public Transform firepointBrainblaster5;
    public Transform firepointBrainblaster6;
    public Transform firepointBrainblaster7;
    public Transform firepointBrainblaster8;
    public Transform firepointBrainblaster9;
    public Transform firepointBrainblaster10;
    public Transform firepointBrainblaster11;
    public Transform firepointBrainblaster12;
    public Transform firepointBrainblaster13;
    public Transform firepointBrainblaster14;
    public Transform firepointBrainblaster15;
    public Transform firepointBrainblaster16;
    public Transform firepointBrainblaster17;
    public Transform firepointBrainblaster18;
    public Transform firepointBrainblaster19;
    public Transform locationMonster;
    public GameObject eyeBullet;
    public GameObject eyeBulletShootingEffect;
    private int nextSkill;
    public GameObject skullBomb;
    public GameObject spinningAxe;
    public GameObject bloodShower;
    public GameObject eyeBlaster;
    public GameObject eyeBlasterCharging;
    public GameObject hellfire;
    public GameObject brainBlaster;
    public GameObject brainBlasterCharging;
    public bool is2ndPhase;

    public void Awake()
    {
        is2ndPhase = false;
        Invoke("SkillChoices_phaseOne", 3);
    }

    private void Update()
    {
        TheMonster theMonster = GetComponent<TheMonster>();
        if (theMonster.health < 1000)
        {
            is2ndPhase = true;
        }

        if (theMonster.health <= 0)
        {
            CancelInvoke();
        }
       
    }

    public void SkillChoices_phaseOne()
    {
        TheMonster theMonster = GetComponent<TheMonster>();
        if (theMonster.health > 1000)
        {
            nextSkill = Random.Range(0, 4);
            switch (nextSkill)
            {
                case 0:
                    ShootBullet();
                    Invoke("ShootBullet", 0.3f);
                    Invoke("ShootBullet", 0.6f);
                    break;
                case 1:
                    ShootSkullBomb();
                    Invoke("ShootSkullBomb", 1);
                    break;
                case 2:
                    ShootAxe();
                    break;
                case 3:
                    Hellfire();
                    break;
                default:
                    break;
            }
        }
        if (is2ndPhase)
        {
            CancelInvoke();
            Invoke("SkillChoices_phaseTwo", 13);
            Invoke("ShootEyeLaser2ndPhase", Random.Range(13, 15));
        }
        else
        { 
            Invoke("SkillChoices_phaseOne", Random.Range(3, 6));
        }
    }

    public void SkillChoices_phaseTwo()
    {
        nextSkill = Random.Range(0, 3);
        switch (nextSkill)
        {
            case 0:
                BloodShowerOne();
                Invoke("BloodShowerTwo", 1);
                Invoke("BloodShowerOne", 2);
                break;
            case 1:
                GameObject instantiatedEyeBlasterCharging = Instantiate(eyeBlasterCharging, firepointEyeBlaster.position, firepointEyeBlaster.rotation);
                instantiatedEyeBlasterCharging.transform.SetParent(transform);
                Invoke("EyeBlaster", 0.85f);
                break;
            case 2:
                int mulitHits = Random.Range(5, 8);
                for (int i = 1; i <= mulitHits; i++)
                {
                    Invoke("BrainBlaster", i * 0.7f);
                }
                break;
            default:
                break;
        }
        Invoke("SkillChoices_phaseTwo", Random.Range(6, 8));
    }

    public void ShootEyeLaser2ndPhase()
    {
        ShootBullet();
        Invoke("ShootBullet", 0.25f);
        Invoke("ShootEyeLaser2ndPhase", Random.Range(3, 6));
    }

    void ShootBullet()
    {
        FindObjectOfType<AudioManager>().Play("EyeLaser");

        Instantiate(eyeBullet, firepointEye.position, firepointEye.rotation);
        Instantiate(eyeBulletShootingEffect, firepointEye.position, firepointEye.rotation);
    }

    void ShootSkullBomb()
    {
        Instantiate(skullBomb, firepointMouth.position, firepointMouth.rotation);
    }

    void ShootAxe()
    {
        Instantiate(spinningAxe, firepointAxe0.position, firepointAxe0.rotation);
        Instantiate(spinningAxe, firepointAxe1.position, firepointAxe1.rotation);
        Instantiate(spinningAxe, firepointAxe2.position, firepointAxe2.rotation);
        Instantiate(spinningAxe, firepointAxe3.position, firepointAxe3.rotation);
        Instantiate(spinningAxe, firepointAxe4.position, firepointAxe4.rotation);
        Instantiate(spinningAxe, firepointAxe5.position, firepointAxe5.rotation);
    }

    void Hellfire()
    {
        GameObject instantiatedHellfire = Instantiate(hellfire, firepointHellfire.position, firepointHellfire.rotation);
        instantiatedHellfire.transform.SetParent(transform);
    }

    void BloodShowerOne()
    {
        FindObjectOfType<AudioManager>().Play("BloodShower");

        int nextLocation = Random.Range(0, 4);
        Vector2 firepointBloodShower0_opposite = new Vector2(locationMonster.position.x * 2 - firepointBloodShower0.position.x, firepointBloodShower0.position.y);
        Vector2 firepointBloodShower1_opposite = new Vector2(locationMonster.position.x * 2 - firepointBloodShower1.position.x, firepointBloodShower1.position.y);
        Vector2 firepointBloodShower2_opposite = new Vector2(locationMonster.position.x * 2 - firepointBloodShower2.position.x, firepointBloodShower2.position.y);
        Vector2 firepointBloodShower3_opposite = new Vector2(locationMonster.position.x * 2 - firepointBloodShower3.position.x, firepointBloodShower0.position.y);
        switch (nextLocation)
        {
            case 0:
                Instantiate(bloodShower, firepointBloodShower0.position, firepointBloodShower0.rotation);
                Instantiate(bloodShower, firepointBloodShower1.position, firepointBloodShower1.rotation);
                Instantiate(bloodShower, firepointBloodShower2.position, firepointBloodShower2.rotation);
                Instantiate(bloodShower, firepointBloodShower0_opposite, firepointBloodShower0.rotation);
                Instantiate(bloodShower, firepointBloodShower1_opposite, firepointBloodShower1.rotation);
                Instantiate(bloodShower, firepointBloodShower2_opposite, firepointBloodShower2.rotation);
                break;
            case 1:
                Instantiate(bloodShower, firepointBloodShower0.position, firepointBloodShower0.rotation);
                Instantiate(bloodShower, firepointBloodShower1.position, firepointBloodShower1.rotation);
                Instantiate(bloodShower, firepointBloodShower3.position, firepointBloodShower3.rotation);
                Instantiate(bloodShower, firepointBloodShower0_opposite, firepointBloodShower0.rotation);
                Instantiate(bloodShower, firepointBloodShower1_opposite, firepointBloodShower1.rotation);
                Instantiate(bloodShower, firepointBloodShower3_opposite, firepointBloodShower3.rotation);
                break;
            case 2:
                Instantiate(bloodShower, firepointBloodShower0.position, firepointBloodShower0.rotation);
                Instantiate(bloodShower, firepointBloodShower2.position, firepointBloodShower2.rotation);
                Instantiate(bloodShower, firepointBloodShower3.position, firepointBloodShower3.rotation);
                Instantiate(bloodShower, firepointBloodShower0_opposite, firepointBloodShower0.rotation);
                Instantiate(bloodShower, firepointBloodShower2_opposite, firepointBloodShower2.rotation);
                Instantiate(bloodShower, firepointBloodShower3_opposite, firepointBloodShower3.rotation);
                break;
            case 3:
                Instantiate(bloodShower, firepointBloodShower1.position, firepointBloodShower1.rotation);
                Instantiate(bloodShower, firepointBloodShower2.position, firepointBloodShower2.rotation);
                Instantiate(bloodShower, firepointBloodShower3.position, firepointBloodShower3.rotation);
                Instantiate(bloodShower, firepointBloodShower1_opposite, firepointBloodShower1.rotation);
                Instantiate(bloodShower, firepointBloodShower2_opposite, firepointBloodShower2.rotation);
                Instantiate(bloodShower, firepointBloodShower3_opposite, firepointBloodShower3.rotation);
                break;
            default:
                break;
        }
    }

    void BloodShowerTwo()
    {
        FindObjectOfType<AudioManager>().Play("BloodShower");

        Vector2 firepointBloodShower4_opposite = new Vector2(locationMonster.position.x * 2 - firepointBloodShower4.position.x, firepointBloodShower4.position.y);
        Vector2 firepointBloodShower5_opposite = new Vector2(locationMonster.position.x * 2 - firepointBloodShower5.position.x, firepointBloodShower5.position.y);
        Vector2 firepointBloodShower6_opposite = new Vector2(locationMonster.position.x * 2 - firepointBloodShower6.position.x, firepointBloodShower6.position.y);
        Instantiate(bloodShower, firepointBloodShower4.position, firepointBloodShower4.rotation);
        Instantiate(bloodShower, firepointBloodShower5.position, firepointBloodShower5.rotation);
        Instantiate(bloodShower, firepointBloodShower6.position, firepointBloodShower6.rotation);
        Instantiate(bloodShower, firepointBloodShower4_opposite, firepointBloodShower4.rotation);
        Instantiate(bloodShower, firepointBloodShower5_opposite, firepointBloodShower5.rotation);
        Instantiate(bloodShower, firepointBloodShower6_opposite, firepointBloodShower6.rotation);
    }

    void EyeBlaster()
    {
        FindObjectOfType<AudioManager>().Play("EyeBlaster");

        Instantiate(eyeBlaster, firepointEyeBlaster.position, firepointEyeBlaster.rotation);
    }

    void BrainBlaster()
    {
        Transform[] firepointBrainBlasters = { firepointBrainblaster0, firepointBrainblaster1, firepointBrainblaster2, firepointBrainblaster3, firepointBrainblaster4
        , firepointBrainblaster5, firepointBrainblaster6, firepointBrainblaster7, firepointBrainblaster8, firepointBrainblaster9, firepointBrainblaster10, firepointBrainblaster11,
            firepointBrainblaster12, firepointBrainblaster13, firepointBrainblaster14, firepointBrainblaster15, firepointBrainblaster16, firepointBrainblaster17, firepointBrainblaster18, firepointBrainblaster19};
        int nextPosition1 = Random.Range(0, 10);
        int nextPosition2 = Random.Range(10, 20);
        Instantiate(brainBlasterCharging, firepointBrainBlasters[nextPosition1].position, firepointBrainBlasters[nextPosition1].rotation);
        Instantiate(brainBlasterCharging, firepointBrainBlasters[nextPosition2].position, firepointBrainBlasters[nextPosition2].rotation);
    }
}
