﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EyeBlaster : MonoBehaviour
{
    public float damage = 20f;

    private void Start()
    {
        Invoke("FinishTheSkill", 0.5f);
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
        if (thePlayer != null)
        {
            thePlayer.TakeDamage(damage);
        }
    }

    public void FinishTheSkill()
    {
        Destroy(gameObject);
    }
}
