﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class EasterEgg : MonoBehaviour
{
    public GameObject newMonster;
    private bool monsterShot = false;
    private Vector3 desiredPosition;
    private float shakeDuration = 0f;
    private float shakeMagnitude = 0.7f;
    private float dampingSpeed = 1f;
    private bool isShakeTriggered = false;
    private Vector3 initialPosition;

    // Start is called before the first frame update
    IEnumerator Start()
    {
        FindObjectOfType<AudioManager>().Stop("Youwin");
        desiredPosition = new Vector3(13.03f, -7.2f, -10);
        yield return new WaitForSeconds(6);
        FindObjectOfType<AudioManager>().Play("Laugh_newmonster");
        yield return new WaitForSeconds(6);

        FindObjectOfType<AudioManager>().Play("SuspenseSound1");
        monsterShot = true;
        yield return new WaitForSeconds(6);
        FindObjectOfType<AudioManager>().Play("SuspenseSound2");
        ShakeTrigger();
        yield return new WaitForSeconds(7);
        SceneManager.LoadScene("Mainmenu");
    }

    private void Update()
    {
        if (monsterShot)
        {
            transform.position = Vector3.Lerp(transform.position, desiredPosition, 0.01f);
        }

        if (isShakeTriggered)
        {
            if (shakeDuration > 0)
            {
                transform.localPosition = desiredPosition + Random.insideUnitSphere * shakeMagnitude;

                shakeDuration -= Time.deltaTime * dampingSpeed;
            }
            else
            {
                shakeDuration = 0f;
                transform.localPosition = desiredPosition;
                isShakeTriggered = false;
            }
        }
    }

    void ShakeTrigger()
    {
        shakeDuration = 2.0f;
        isShakeTriggered = true;
    }
}
