﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Gameover : MonoBehaviour
{
    private void Start()
    {
        FindObjectOfType<AudioManager>().StopAll();
        FindObjectOfType<AudioManager>().Play("Gameover");
    }
    public void Play()
    {
        FindObjectOfType<AudioManager>().Play("BGM_1stPhase");
        FindObjectOfType<AudioManager>().Play("ClickSound");
        SceneManager.LoadScene("BossFight");
    }

    public void Menu()
    {
        SceneManager.LoadScene("Mainmenu");
    }

    public void Exit()
    {
        Application.Quit();
    }
}
