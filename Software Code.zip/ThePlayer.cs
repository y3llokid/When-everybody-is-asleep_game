﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class ThePlayer : MonoBehaviour
{
    public float health = 100f;
    public float sniperMode = 0;
    public float sniperModeReplenishment = 7f;
    public float maxSpeed;
    public float jumpPower;
    public int jumpCounter;
    Rigidbody2D rigid;
    Animator animator;
    public bool facingRight = true;
    public GameObject deathEffect;
    public GameObject ughEffect;
    public GameObject fadeout;
    public GameObject aura;
    private GameObject instantiatedAura;
    public Slider healthbar;
    public Slider sniperModeBar;
    public int telCounter;
    private float sniperModeCooling = 0;
    public TextMeshProUGUI hpNumeric;
    public GameObject pointLight2D;

    private void Awake()
    {
        pointLight2D.SetActive(false);
        pointLight2D.transform.SetParent(transform);
        rigid = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        jumpCounter = 0;
        telCounter = 0;
        hpNumeric.text = health.ToString() + "/" + "100";
    }

    private void Update()
    {
        RaycastHit2D raycastHitJumpChecker = Physics2D.Raycast(transform.position, Vector3.down, 1.3f, LayerMask.GetMask("Platform", "Floor"));
        RaycastHit2D raycastWallChecker_right = Physics2D.Raycast(transform.position, Vector3.right, 3.5f, LayerMask.GetMask("Wall"));
        RaycastHit2D raycastWallChecker_left = Physics2D.Raycast(transform.position, Vector3.left, 3.5f, LayerMask.GetMask("Wall"));
        Debug.DrawRay(transform.position, Vector3.down * 1, Color.green);
        if (raycastHitJumpChecker.collider != null)
        {
            jumpCounter = 0;
            animator.SetBool("isAir", false);
        }

        //Player can move when he is alive
        if (health > 0)
        {
            //Jump
            if (Input.GetButtonDown("Jump") && jumpCounter < 2)
            {
                FindObjectOfType<AudioManager>().Play("PlayerJump");
                rigid.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
                jumpCounter++;
                animator.SetBool("isAir", true);
            }

            //Stop Speed
            if (Input.GetButtonUp("Horizontal"))
            {
                rigid.velocity = new Vector2(rigid.velocity.normalized.x * 1f, rigid.velocity.y);
            }

            //Move by Key control in x axis
            float move = Input.GetAxisRaw("Horizontal");

            rigid.AddForce(Vector2.right * move, ForceMode2D.Impulse);

            //limit the max speed
            if (rigid.velocity.x >= maxSpeed)
            {
                rigid.velocity = new Vector2(maxSpeed, rigid.velocity.y);
            }
            else if (rigid.velocity.x < (-1) * maxSpeed)
            {
                rigid.velocity = new Vector2(maxSpeed * (-1), rigid.velocity.y);
            }

            //Direction Changes
            if (move > 0 && !facingRight)
                Flip();
            else if (move < 0 && facingRight)
                Flip();

            //Walking Animation
            if (Mathf.Abs(rigid.velocity.x) < 0.8f)
            {
                animator.SetBool("isWalking", false);
                telCounter = 0;
            }
            else
            {
                animator.SetBool("isWalking", true);
            }

            //Teleport
            if (move > 0 && Input.GetKeyDown(KeyCode.Z) && telCounter < 2 && raycastWallChecker_right == false)
            {
                Instantiate(fadeout, transform.position, transform.rotation);
                transform.position = new Vector2(transform.position.x + 3.5f, transform.position.y);
                telCounter++;
            }
            else if (move < 0 && Input.GetKeyDown(KeyCode.Z) && telCounter < 2 && raycastWallChecker_left == false)
            { 
                Instantiate(fadeout, transform.position, transform.rotation);
                transform.position = new Vector2(transform.position.x - 3.5f, transform.position.y);
                telCounter++;
            }
            else if (raycastHitJumpChecker.collider == false && Input.GetKeyDown(KeyCode.V))
            {
                Instantiate(fadeout, transform.position, transform.rotation);
                transform.position = new Vector2(transform.position.x, transform.position.y -2);
            }

            //Sniper Mode
            if (sniperMode >= 100 && Input.GetKeyDown(KeyCode.F))
            {
                animator.SetBool("isSniper", true);
                sniperModeCooling = 14f;
                sniperModeReplenishment = 0;
                instantiatedAura = Instantiate(aura, transform.position, transform.rotation);
                instantiatedAura.transform.SetParent(transform);
            }

            if (sniperMode <= 0)
            {
                animator.SetBool("isSniper", false);
                sniperModeCooling = 0;
                sniperModeReplenishment = 7f;
                Destroy(instantiatedAura);
            }
            if (sniperMode < 100)
            {
                sniperMode = sniperMode + sniperModeReplenishment * Time.deltaTime;
            }
            sniperMode = sniperMode - sniperModeCooling * Time.deltaTime;
            sniperModeBar.value = sniperMode;
        }

        //Player hp in numeric indication
        if (health < 0)
        {
            hpNumeric.text = "0/100";

        }
        else
        {
            hpNumeric.text = health.ToString("f0") + "/" + "100";
        }
    }

    void Flip()
    {
        facingRight = !facingRight;
        transform.Rotate(0f, 180f, 0f);
    }

    public void TakeDamage(float damage)
    {
        FindObjectOfType<AudioManager>().Play("PlayerDamaged");
        FindObjectOfType<AudioManager>().Play("PlayerUgh");

        health -= damage;
        healthbar.value = health;
        Quaternion quaternion = new Quaternion(0, 0, 0, 0);
        if(health > 0)
            Instantiate(ughEffect, transform.position, quaternion);
        if (health <= 0)
        {
            FindObjectOfType<AudioManager>().Stop("BGM_1stPhase");
            FindObjectOfType<AudioManager>().Stop("BGM_2ndPhase");

            gameObject.layer = 16;
            Destroy(instantiatedAura);
            FindObjectOfType<AudioManager>().Play("PlayerDeath");
            pointLight2D.SetActive(true);
            animator.SetBool("isDead", true);
            if (!facingRight)
                Flip();
            Invoke("Gameover", 6);
        }
            
    }

    public void Gameover()
    {
        SceneManager.LoadScene("Gameover");
    }
}
