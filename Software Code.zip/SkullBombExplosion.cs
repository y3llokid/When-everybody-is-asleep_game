﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkullBombExplosion : MonoBehaviour
{
    public float damage = 15f;
    Animator animator;

    private void Start()
    {
        FindObjectOfType<AudioManager>().Play("SkullBombExplosion");

        animator = GetComponent<Animator>();
        Invoke("DestroyObject", 0.5f);
    }

    private void OnTriggerEnter2D(Collider2D hitInfo)
    {
        ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
        if (thePlayer != null)
        {
            thePlayer.TakeDamage(damage);
        }
    }
    public void DestroyObject()
    {
        Destroy(gameObject);
    }
}
