﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{
    public TextMeshProUGUI timerText;
    public float startTime;
    public float remainingTime;
    public GameObject mainCamera;
    public GameObject monster;
    public bool isTimeover = false;

    // Start is called before the first frame update
    void Start()
    {
        startTime = 300f + Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        GameObject theMonster = GameObject.Find("TheMonster");
        TheMonster theMonsterScript = theMonster.GetComponent<TheMonster>();
        if (theMonsterScript.health > 0 && !isTimeover)
        {
            remainingTime = startTime - Time.time;
        }

        string minutes = ((int)remainingTime / 60).ToString();
        string seconds = (remainingTime % 60).ToString("f2");

        timerText.text = minutes + ":" + seconds;

        if (remainingTime <= 0)
        {
            FindObjectOfType<AudioManager>().Stop("BGM_1stPhase");
            FindObjectOfType<AudioManager>().Stop("BGM_2ndPhase");
            FindObjectOfType<AudioManager>().Stop("");
            isTimeover = true;
            remainingTime = 0;
            monster.layer = 16;
            mainCamera.GetComponent<CameraBehavior>().TriggerShake();
            Invoke("Gameover", 5f);
        }
    }

    public void Gameover()
    {
        SceneManager.LoadScene("Gameover");
    }
}
