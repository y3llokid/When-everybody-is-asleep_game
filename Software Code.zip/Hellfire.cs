﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hellfire : MonoBehaviour
{
    public float damage = 5f;
    public float damageInterval = 0.6f;
    private bool isPlayerBeingDamaged;
    private void Start()
    {
        Invoke("FinishTheSkill", 3f);
        isPlayerBeingDamaged = false;
    }

    //private void OnTriggerEnter2D(Collider2D hitInfo)
    //{
    //    ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
    //    if (thePlayer != null)
    //    {
    //        thePlayer.TakeDamage(damage);
    //    }
    //}
    private void OnTriggerStay2D(Collider2D hitInfo)
    {
        ThePlayer thePlayer = hitInfo.GetComponent<ThePlayer>();
        if (thePlayer != null && !isPlayerBeingDamaged)
        {
            this.StartCoroutine(fireDamage(damageInterval));
        }
    }

    public void FinishTheSkill()
    {
        Destroy(gameObject);
    }

    IEnumerator fireDamage(float time)
    {
        FindObjectOfType<ThePlayer>().TakeDamage(damage);
        isPlayerBeingDamaged = true;
        yield return new WaitForSeconds(time);
        isPlayerBeingDamaged = false;
    }
}
