﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class TheMonster : MonoBehaviour
{
    public float health = 2400f;
    public Rigidbody2D rigid;
    public int nextMove_X;
    public int nextMove_Y;
    float distanceToPlayer_X;
    float distanceToPlayer_Y;
    public float speed_X = 2f;
    public float speed_Y = 0f;
    public float jumpPower;
    public bool facingRight;
    public Animator animator;
    public Slider healthBar;
    public Slider rageBar;
    public CapsuleCollider2D CapsuleCollider2D;
    public CircleCollider2D circleCollider2D_eye;
    public Transform Player;
    private float rage = 5;
    private float rageGage = 0;
    private float rageCooling = 0.05f;
    private float rageSpeed = 1;
    private float hpReplenishment = 0;
    public TextMeshProUGUI hpNumeric;

    private void Awake()
    {
        facingRight = false;
        animator = GetComponent<Animator>();
        rigid = GetComponent<Rigidbody2D>();
        CapsuleCollider2D = GetComponent<CapsuleCollider2D>();
        circleCollider2D_eye = GetComponent<CircleCollider2D>();
        Invoke("Jumppy", 0.5f);
        hpNumeric.text = health.ToString("f0") + "/" + 2400;
    }

    private void Update()
    {
        //Change Direction
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("TheMonster_IDLE")|| animator.GetCurrentAnimatorStateInfo(0).IsName("2ndPhase_IDLE"))
        {
            if (rigid.velocity.x > 0 && !facingRight)
                Flip();
            else if (rigid.velocity.x < 0 && facingRight)
                Flip();
        }

        //HealthBar Indicator

        //Entering The Second Phase
        if (health < 1000 && animator.GetCurrentAnimatorStateInfo(0).IsName("TheMonster_IDLE"))
        {
            gameObject.layer = 16;
            animator.SetBool("is2ndPhase", true);
            rigid.velocity = new Vector2(0, 0);
        }

        //Entering The Rage Mode
        if (rageGage >= 100)
        {
            //isRage = true;
            rageCooling = 20f;
            rageSpeed = 3;
            hpReplenishment = 35f;
            rage = 0;
        }else if (rageGage <= 0)
        {
            rageCooling = 5f;
            rageSpeed = 1;
            hpReplenishment = 0;
            rage = 5;
        }

        if (animator.GetCurrentAnimatorStateInfo(0).IsName("2ndPhase_IDLE"))
        {
            gameObject.layer = 10;
            CapsuleCollider2D.size = new Vector2(0.35f, 0.165f);
            CapsuleCollider2D.offset = new Vector2(.03f, 0.35f);
            CapsuleCollider2D.direction = CapsuleDirection2D.Horizontal;
            circleCollider2D_eye.enabled = true;
            rigid.gravityScale = 0;
        }

        //HP Replenishment
        if (health < 2400 && (animator.GetCurrentAnimatorStateInfo(0).IsName("2ndPhase_IDLE") || animator.GetCurrentAnimatorStateInfo(0).IsName("TheMonster_IDLE")))
        { 
            health = health + hpReplenishment * Time.deltaTime;
            healthBar.value = health;
        }

        //Rage gage drops
        rageGage = rageGage - rageCooling * Time.deltaTime;
        rageBar.value = rageGage;

        //Monster hp indication in numeric value
        if (health < 0)
        {
            hpNumeric.text = "0/2400";
        }
        else
        {
            hpNumeric.text = health.ToString("f0") + "/" + 2400;
        }
    }

    private void FixedUpdate()
    {
        if (health > 0)
        {
            distanceToPlayer_X = transform.position.x - Player.position.x;
            speed_X = Mathf.Abs(distanceToPlayer_X / 3);
            if (health >= 1000)
                jumpPower = Random.Range(4000, 5000);
            else
                jumpPower = 0;
            //PhaseOne movement
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("TheMonster_IDLE"))
            {
                if (distanceToPlayer_X > 1.5f)
                {
                    nextMove_X = -1;
                }
                else if (distanceToPlayer_X < -1.5f)
                {
                    nextMove_X = 1;
                }
                else
                {
                    nextMove_X = 0;
                }
                //Move
                rigid.velocity = new Vector2(nextMove_X * speed_X * rageSpeed, rigid.velocity.y);

                //Platform Check
                Vector2 frontVec = new Vector2(rigid.position.x + nextMove_X, rigid.position.y);
                RaycastHit2D raycastHit = Physics2D.Raycast(frontVec, Vector3.down * 2, 10, LayerMask.GetMask("Platform"));
                if (raycastHit.collider == null)
                {
                    rigid.velocity = new Vector2(0, 0);
                }
            }

            //PhaseTwo movement
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("2ndPhase_IDLE"))
            {
                distanceToPlayer_Y = transform.position.y - Player.position.y;
                speed_Y = Mathf.Abs(distanceToPlayer_Y / 3);
                if (distanceToPlayer_X > 0.5f)
                {
                    nextMove_X = -1;
                }
                else if (distanceToPlayer_X < -0.5f)
                {
                    nextMove_X = 1;
                }
                else
                {
                    nextMove_X = 0;
                }

                if (distanceToPlayer_Y > 0.2f)
                {
                    nextMove_Y = -1;
                }
                else if (distanceToPlayer_Y < -0.2f)
                {
                    nextMove_Y = 1;
                }
                else
                {
                    nextMove_Y = 0;
                }
                //Move
                rigid.velocity = new Vector2(nextMove_X * speed_X * rageSpeed, nextMove_Y * speed_Y * rageSpeed);
            }
        }
    }

    public void TakeDamage (float damage)
    {
        FindObjectOfType<AudioManager>().Play("MonsterDamaged");

        health -= damage;
        healthBar.value = health;
        rageGage += rage;
        rageBar.value = rageGage;

        if (health <= 0)
        {
            rigid.velocity = new Vector2(0 , 0);
            FindObjectOfType<ThePlayer>().gameObject.layer = 16;
            animator.SetBool("isDead", true);
            Invoke("DieAndScream", 4.5f);
            Invoke("Die", 8);
        }
    }

    void Flip()
    {
        facingRight = !facingRight;
        transform.Rotate(0f, 180f, 0f);
    }

    void Die()
    {
        Destroy(gameObject);
    }

    void DieAndScream()
    {
        FindObjectOfType<AudioManager>().Play("MonsterDeath");
    }

    void Jumppy()
    {
        rigid.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
        Invoke("Jumppy", 1.2f);
    }

    private void OnDestroy()
    {
        if (health <= 0)
        {
            GameObject timer = GameObject.Find("Canvas");
            var timerScript = timer.GetComponent<Timer>();
            float t = 300f - timerScript.remainingTime;
            string minutes = ((int)t / 60).ToString();
            string seconds = (t % 60).ToString("f2");
            string score = minutes + " min " + seconds + " sec";
            PlayerPrefs.SetString("ThisScore", score);
            PlayerPrefs.SetFloat("ThisScore_float", t);
            if (PlayerPrefs.GetString("HighScore", "-----").Equals("-----"))
            {
                PlayerPrefs.SetString("HighScore", score);
                PlayerPrefs.SetFloat("HighScore_float", t);
            }
            else if (t < PlayerPrefs.GetFloat("HighScore_float", 0))
            {
                PlayerPrefs.SetString("HighScore", score);
                PlayerPrefs.SetFloat("HighScore_float", t);
            }
            SceneManager.LoadScene("Youwin");
        }
    }
}
