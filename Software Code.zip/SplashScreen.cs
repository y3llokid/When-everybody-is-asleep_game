﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using TMPro;

public class SplashScreen : MonoBehaviour
{
    public Image splashImage;
    public TextMeshProUGUI creditsToMe;
    public TextMeshProUGUI creditsToZapsplat;

    public TextMeshProUGUI story1;
    public TextMeshProUGUI story2;
    public TextMeshProUGUI story3;
    public TextMeshProUGUI story4;

    public TextMeshProUGUI skipText;

    public GameObject skipButton;

    IEnumerator Start()
    {
        splashImage.canvasRenderer.SetAlpha(0.0f);
        creditsToMe.canvasRenderer.SetAlpha(0.0f);
        creditsToZapsplat.canvasRenderer.SetAlpha(0.0f);
        story1.canvasRenderer.SetAlpha(0.0f);
        story2.canvasRenderer.SetAlpha(0.0f);
        story3.canvasRenderer.SetAlpha(0.0f);
        story4.canvasRenderer.SetAlpha(0.0f);
        skipText.canvasRenderer.SetAlpha(0.0f);

        //Y3LLOKID logo
        splashImage.CrossFadeAlpha(1.0f, 1.5f, false);
        yield return new WaitForSeconds(0.5f);
        FindObjectOfType<AudioManager>().Play("SplashScreen");
        yield return new WaitForSeconds(2f);

        //Credits To Y3LLOKID_production
        creditsToMe.CrossFadeAlpha(1.0f, 1.5f, false);
        yield return new WaitForSeconds(1.5f);

        //Credits To Zapsplat.com
        creditsToZapsplat.CrossFadeAlpha(1.0f, 1.5f, false);
        yield return new WaitForSeconds(3f);
        FadeOut();
        yield return new WaitForSeconds(3f);

        //Story fade in
        skipButton.SetActive(true);
        skipText.CrossFadeAlpha(1.0f, 1.5f, false);
        story1.CrossFadeAlpha(1.0f, 1.5f, false);
        yield return new WaitForSeconds(6f);
        story2.CrossFadeAlpha(1.0f, 1.5f, false);
        yield return new WaitForSeconds(6f);
        story3.CrossFadeAlpha(1.0f, 1.5f, false);
        yield return new WaitForSeconds(6f);
        story4.CrossFadeAlpha(1.0f, 1.5f, false);
        yield return new WaitForSeconds(8f);

        //Story fade out
        story1.CrossFadeAlpha(0.0f, 2.5f, false);
        story2.CrossFadeAlpha(0.0f, 2.5f, false);
        story3.CrossFadeAlpha(0.0f, 2.5f, false);
        story4.CrossFadeAlpha(0.0f, 2.5f, false);
        skipText.CrossFadeAlpha(0.0f, 2.5f, false);
        yield return new WaitForSeconds(3f);

        SceneManager.LoadScene("Mainmenu");
    }

    void FadeOut()
    {
        splashImage.CrossFadeAlpha(0.0f, 2.5f, false);
        creditsToMe.CrossFadeAlpha(0.0f, 2.5f, false);
        creditsToZapsplat.CrossFadeAlpha(0.0f, 2.5f, false);
    }

    public void Skip()
    {
        SceneManager.LoadScene("Mainmenu");
    }
}
